package com.iqquestlearning.ui;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IqQuestLearningUiApplication {

	public static void main(String[] args) {
		SpringApplication.run(IqQuestLearningUiApplication.class, args);
	}

}
