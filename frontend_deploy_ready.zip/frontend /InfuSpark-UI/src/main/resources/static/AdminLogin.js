const BASE_URL = 'BASE_URL';

document.getElementById('loginForm').addEventListener('submit', function (event) {
    event.preventDefault();
    clearErrors();

    const isValid = validateForm();
    if (!isValid) return;

    loginUser();
	
});

function validateForm() {
    let isValid = true;
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value.trim();

    if (!email) {
        showError('emailError', 'Email is required.');
        isValid = false;
    }

    if (!password) {
        showError('passwordError', 'Password is required.');
        isValid = false;
    }

    return isValid;
}

function showError(id, message) {
    const element = document.getElementById(id);
    element.textContent = message;
    element.style.display = 'block';
}

function clearErrors() {
    document.querySelectorAll('.text-danger').forEach(el => {
        el.textContent = '';
        el.style.display = 'none';
    });

    const msg = document.getElementById('message');
    msg.textContent = '';
    msg.style.display = 'none';
    msg.classList.remove('alert-success', 'alert-danger');
}

function loginUser() {
    const loginData = {
        email: document.getElementById('email').value,
        password: document.getElementById('password').value
    };

    fetch(BASE_URL + '/api/admin/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(loginData)
    })
    .then(response => {
        if (!response.ok) {
            return response.json().then(message => { throw new Error(message); });
        }
        return response.json();
    })
	.then(data => {
	        const msg = document.getElementById('message');
	        msg.textContent = data.message;
	        msg.classList.add('alert', 'alert-success');
	        msg.style.display = 'block';

	        // ✅ Store admin details in localStorage for future use
	        localStorage.setItem('admin', JSON.stringify(data.admin));

	        setTimeout(() => {
	            window.location.href = 'AdminDashBoard.html';
	        }, 1000);
	    })
    /*.then(message => {
        const msg = document.getElementById('message');
        msg.textContent = message;
        msg.classList.add('alert', 'alert-success');
        msg.style.display = 'block';
		setTimeout(() => {
			
		            window.location.href = 'AdminDashBoard.html';
		        }, 1000);
    })*/
    .catch(error => {
        const msg = document.getElementById('message');
        msg.textContent = error.message;
        msg.classList.add('alert', 'alert-danger');
        msg.style.display = 'block';
    });
}

function clearForm() {
    document.getElementById('email').value = '';
    document.getElementById('password').value = '';
}
