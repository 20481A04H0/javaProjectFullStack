package com.iqquestlearning.ui;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IqQuestLearningUiApplicationTests {

	@Test
	void contextLoads() {
	}

}
