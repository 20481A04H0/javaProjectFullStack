
// Auto-generated config.js
const BASE_URL = (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') ? 'BASE_URL' : ('https://' + window.location.hostname);
