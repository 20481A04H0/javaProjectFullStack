
package com.iqquestlearning.be.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.iqquestlearning.be.entity.Course;
import com.iqquestlearning.be.entity.Trainer;
import com.iqquestlearning.be.models.CourseDto;
import com.iqquestlearning.be.models.CourseRequestDTO;
import com.iqquestlearning.be.models.CourseResponseDTO;
import com.iqquestlearning.be.repository.CourseRepository;
import com.iqquestlearning.be.service.CourseService;

import jakarta.transaction.Transactional;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/course")
@CrossOrigin(origins = "*")
public class CourseControlller {
	@Autowired
	private CourseRepository courseRepository;

	@Autowired
	private CourseService courseService;

	@PostMapping("/saveCourse")
	public ResponseEntity<String> saveCourse(@Valid @RequestBody CourseRequestDTO courserequestdto,
			BindingResult bindingResult) {
		if (bindingResult.hasErrors()) {
			return ResponseEntity.badRequest().body("Validation errors occurred.");
		}
		courseService.saveCourse(courserequestdto);
		return ResponseEntity.status(HttpStatus.CREATED).body("course created successfully.");
	}

	
	@GetMapping("/getAllCoursesList")
	@Transactional
	public List<CourseDto> getAllCoursesList() {
	    List<Course> courses = courseRepository.findAll();

	    return courses.stream()
	        .map(course -> {
	            List<String> trainerNames = course.getTrainers() != null
	                ? course.getTrainers().stream()
	                        .map(Trainer::getName)
	                        .toList()
	                : List.of();

	            return new CourseDto(course.getId(), course.getName(), trainerNames);
	        })
	        .toList();
	}



	@GetMapping("/getCoursesCount")
	public ResponseEntity<Long> getCoursesCount() {
	    long count = courseRepository.count();
	    return ResponseEntity.ok(count);
	}
	
	/*
	 * @GetMapping("/getCourseById/{id}") public ResponseEntity<CourseDto>
	 * getCourseById(@PathVariable int id) { CourseDto courseDto =
	 * courseService.getCourseById(id); return ResponseEntity.ok(courseDto); }
	 */
	@GetMapping("/getCourseById/{id}")
	public ResponseEntity<CourseDto> getCourseDtoById(@PathVariable int id) {
	    return ResponseEntity.ok(courseService.getCourseDtoById(id));
	}

	@PutMapping("/updateCourse")
	public ResponseEntity<CourseDto> updateCourse(@RequestBody CourseDto updatedCourse) {
	    CourseDto course = courseService.updateCourse(updatedCourse);
	    return ResponseEntity.ok(course);
	}
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<?> deleteCourse(@PathVariable Long id) {
	    courseService.deleteCourseById(id);
	    return ResponseEntity.ok("Course deleted successfully");
	}
	

    @GetMapping("/getAllCourses")
    public List<Course> getAllCourses() {
        return courseRepository.findAll();
    }
}