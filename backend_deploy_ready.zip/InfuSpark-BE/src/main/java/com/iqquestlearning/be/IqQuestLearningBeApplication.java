package com.iqquestlearning.be;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IqQuestLearningBeApplication {

	public static void main(String[] args) {
		SpringApplication.run(IqQuestLearningBeApplication.class, args);
	}

}
