package com.iqquestlearning.be.repository;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.iqquestlearning.be.entity.Course;
public interface CourseRepository extends JpaRepository<Course, Integer> {

	Optional<Course> findById(Integer id);

	void deleteById(Integer id);

	List<Course> findAllByOrderByIdAsc();

	/* List<Course> findAllById(List<Course> courseIds); */

}


