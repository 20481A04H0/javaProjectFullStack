package com.iqquestlearning.be.models;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor 
public class CourseResponseDTO {
	private int id;
	private String Name;
	public int getId() {
		return id;
	}
	public String getName()
	{
		return Name;
	}
	public void setId(int id2) {
		this.id=id2;
		// TODO Auto-generated method stub
		
	}
	public void setName(String name2) {
		// TODO Auto-generated method stub
		this.Name=name2;
	}
}
