package com.iqquestlearning.be.entity;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Trainer { 
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    private String email;

    private String phone;

    private String specialization;

    private int experience; 

    private boolean active;

	public void setname(String name2) {
		// TODO Auto-generated method stub
		this.name=name2;
	}

	public void setemail(String email2) {
		// TODO Auto-generated method stub
		this.email=email2;
	}

	public void setphone(String phone2) {
		// TODO Auto-generated method stub
		this.phone=phone2;
		
	}

	public void setspecialization(String specialization2) {
		// TODO Auto-generated method stub
		this.specialization=specialization2;
	}

	public void setexperience(int experience2) {
		// TODO Auto-generated method stub
		this.experience=experience2;
		
	}

	public void setactive(boolean b) {
		// TODO Auto-generated method stub
		this.active=b;
		
	}

	public String getName() {
		// TODO Auto-generated method stub
		return name;
	}

	public String getEmail() {
		// TODO Auto-generated method stub
		return email;
	}

	public String getPhone() {
		// TODO Auto-generated method stub
		return phone;
	}

	public String getSpecialization() {
		// TODO Auto-generated method stub
		return specialization;
	}

	public int getExperience() {
		// TODO Auto-generated method stub
		return experience;
	}

	public Long getId() {
		// TODO Auto-generated method stub
		return id;
	}
	
	@ManyToMany(mappedBy = "trainers")
	private List<Course> courses;

	public boolean getActive() {
		// TODO Auto-generated method stub
		return active;
	}

	
}

