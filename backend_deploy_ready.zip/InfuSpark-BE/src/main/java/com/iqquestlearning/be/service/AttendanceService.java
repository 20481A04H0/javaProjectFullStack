package com.iqquestlearning.be.service;

import java.io.InputStream;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;


@Service
public class AttendanceService {

    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

    public Map<String, Map<String, String>> parseAttendanceExcel(MultipartFile file) throws Exception {
        Map<String, Map<String, String>> attendanceMap = new HashMap<>();

        try (InputStream is = file.getInputStream();
             Workbook workbook = new XSSFWorkbook(is)) {

            Sheet sheet = workbook.getSheetAt(0);
            int rowCount = sheet.getPhysicalNumberOfRows();

            for (int r = 1; r < rowCount; r++) {
                Row row = sheet.getRow(r);
                if (row == null) continue;

                Cell emailCell = row.getCell(0); // Assuming email is col 0 in attendance file
                Cell dateCell = row.getCell(1);
                Cell statusCell = row.getCell(2);

                if (emailCell == null || dateCell == null || statusCell == null) continue;

                String email = emailCell.getStringCellValue().trim();

                String dateStr = null;
                if (dateCell.getCellType() == CellType.NUMERIC && DateUtil.isCellDateFormatted(dateCell)) {
                    Date date = (Date) dateCell.getDateCellValue();
                    dateStr = dateFormat.format(date);
                } else if (dateCell.getCellType() == CellType.STRING) {
                    dateStr = dateCell.getStringCellValue().trim();
                }

                String status = statusCell.getStringCellValue().trim();

                if (email.isEmpty() || dateStr == null || status.isEmpty()) continue;

                attendanceMap.computeIfAbsent(email, k -> new HashMap<>())
                             .put(dateStr, status);
            }
        }
        return attendanceMap;
    }
}
