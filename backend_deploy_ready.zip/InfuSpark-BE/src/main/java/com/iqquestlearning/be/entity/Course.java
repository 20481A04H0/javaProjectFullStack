package com.iqquestlearning.be.entity;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
@Entity
@Getter
@Data
@Table(name="Course")
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Course {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	private String name; 

	public void setName(String name2) {
		this.name=name2;
		// TODO Auto-generated method stub
		
	}



    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
        name = "course_trainer",
        joinColumns = @JoinColumn(name = "course_id"),
        inverseJoinColumns = @JoinColumn(name = "trainer_id")
    )
    private List<Trainer> trainers;
	
    
    @ManyToMany(mappedBy = "courses", fetch = FetchType.LAZY)
    private List<Student> students; 
    
	public int getId() {
		// TODO Auto-generated method stub
		return id;
	}

	public String getName() {
		// TODO Auto-generated method stub
		return name;
	}

	public List<Trainer> getTrainers() {
	    return trainers;
	}

	public void setTrainers(List<Trainer> matchedTrainers) {
		this.trainers=matchedTrainers;
		// TODO Auto-generated method stub
		
	}
	
}



