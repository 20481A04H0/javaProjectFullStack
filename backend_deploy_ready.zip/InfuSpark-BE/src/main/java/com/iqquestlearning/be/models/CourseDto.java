package com.iqquestlearning.be.models;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor

public class CourseDto {
    private int id;
    private String name;
    private List<String> trainerNames;

    public CourseDto(int id, String name, List<String> trainerNames) {
        this.id = id;
        this.name = name;
        this.trainerNames = trainerNames;
    }
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public List<String> getTrainerNames() {
        return trainerNames;
    }
    // Getters and setters
}


    // Getters & Setters
