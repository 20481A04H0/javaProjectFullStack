package com.iqquestlearning.be.models;

public class StudentResponseDTO {

}
